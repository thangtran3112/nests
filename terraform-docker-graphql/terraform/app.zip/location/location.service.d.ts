export declare class LocationService {
    private client;
    constructor();
    getLocation(query: string): Promise<any>;
}
